import Login from './login';
import './styles.scss';

const App = () => {

  return (
    <div className="App">
      <Login ></Login>
    </div>
  );
};

export default App;
