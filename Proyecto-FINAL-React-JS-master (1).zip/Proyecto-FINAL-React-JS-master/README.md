## Plan de Pruebas
![image](https://user-images.githubusercontent.com/113057973/206017619-8219f7f6-51b6-4040-b457-453ffdcbff49.png)
![image](https://user-images.githubusercontent.com/113057973/206017726-e3e0657c-2db5-4c1a-ac7d-4ba4a524b913.png)
![image](https://user-images.githubusercontent.com/113057973/206017779-ba3d8eb5-995e-40dc-9310-b7bc5112104a.png)
## Product BackLog
![image](https://user-images.githubusercontent.com/113057973/206018093-93447d17-23f5-4ee7-aab2-7dc78216a388.png)
![image](https://user-images.githubusercontent.com/113057973/206018149-1ee3618d-d3db-4cba-853d-2f681be213b1.png)
![image](https://user-images.githubusercontent.com/113057973/206018207-ce2b94be-bc0d-489e-934b-0b1563f096a3.png)
![image](https://user-images.githubusercontent.com/113057973/206018270-246b9dd9-f57c-4601-a474-147e488a2630.png)
![image](https://user-images.githubusercontent.com/113057973/206018314-ec28aed3-c42f-40c8-8f00-0c616e6a6c7e.png)
![image](https://user-images.githubusercontent.com/113057973/206018341-7dec0a7d-4fb9-450a-8c24-17f552b4fee1.png)
![image](https://user-images.githubusercontent.com/113057973/206018719-3c38a33d-a8b8-457d-b961-ef1bf6fe6f3d.png)
